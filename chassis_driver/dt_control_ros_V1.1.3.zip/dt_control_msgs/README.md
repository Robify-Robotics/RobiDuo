# DT系列底盘 相关 ROS 包

ROS包 消息文件说明

## dt_bms.msg

主板BMS采集

| 类型      | 名称                        | 单位    | 含义       | 说明                      |
|-----------|-----------------------------|---------|------------|---------------------------|
| bool      | is\_offline                 | boolean | 是否离线   | false:在线  true:离线     |
| bool      | is\_warning                 | boolean | 是否告警   | false:无告警  true:有告警 |
| bool      | charge\_mos\_is\_open       | boolean | 充电MOS    | false:关闭  true:开启     |
| bool      | discharge\_mos\_is\_open    | boolean | 放电MOS    | false:关闭  true:开启     |
| uint8     | state                       | number  | 充放电状态 | 0:静止  1:充电  2:放电    |
| float32   | voltage                     | V       | 电压       |                           |
| float32   | current                     | A       | 电流       |                           |
| float32   | soc                         | %       | 电量       |                           |
| float32   | remain\_capacity            | Ah      | 剩余容量   |                           |
| int8      | maximum\_temperature\_value | C       | 最高温     |                           |
| int8      | minimum\_temperature\_value | C       | 最低温     |                           |
| uint8\[\] | warning                     | array   | 告警信息   |                           |

## dt_buff.msg

帧原始数据

| 类型      | 名称                       | 单位  | 含义       | 说明                   |
|-----------|----------------------------|-------|------------|------------------------|
| uint8\[\] | cmd\_80\_state             | array | 底盘状态   | 底盘上传帧原始数据数组 |
| uint8\[\] | cmd\_81\_current           | array | 电机电流   | 底盘上传帧原始数据数组 |
| uint8\[\] | cmd\_82\_charge            | array | 回充状态   | 底盘上传帧原始数据数组 |
| uint8\[\] | cmd\_83\_remote\_ctrl      | array | 遥控数据   | 底盘上传帧原始数据数组 |
| uint8\[\] | cmd\_84\_led\_strip        | array | 灯条状态   | 底盘上传帧原始数据数组 |
| uint8\[\] | cmd\_85\_battery\_info     | array | 电池状态   | 底盘上传帧原始数据数组 |
| uint8\[\] | cmd\_86\_battery\_error    | array | 电池错误   | 底盘上传帧原始数据数组 |
| uint8\[\] | cmd\_A0\_drvie\_error      | array | 驱动器错误 | 底盘上传帧原始数据数组 |
| uint8\[\] | cmd\_A1\_parameter         | array | 底盘参数   | 底盘上传帧原始数据数组 |
| uint8\[\] | cmd\_A2\_software\_version | array | 软件版本   | 底盘上传帧原始数据数组 |
| uint8\[\] | cmd\_A3\_hardware\_version | array | 硬件版本   | 底盘上传帧原始数据数组 |
| uint8\[\] | cmd\_A4\_date              | array | 出货日期   | 底盘上传帧原始数据数组 |



## dt_charge.msg

电机电流

| 类型  | 名称     | 单位    | 含义           | 说明                           |
|-------|----------|---------|----------------|--------------------------------|
| bool  | offline  | boolean | 回充离线       | false:在线  true:离线          |
| uint8 | state    | number  | 回充状态       | 0:空闲  1:红外回充  2:激光回充 |
| bool  | relays   | boolean | 回充头继电器   | false:关闭  true:打开          |
| bool  | button   | boolean | 回充桩行程开关 | false:未触发 true:触发         |
| bool  | voltage  | boolean | 回充头电压     | false:未检测到 true:检测到     |
| uint8 | infrared | number  | 红外回充状态   | 0:寻找中心信号<br> 1:已找到中心信号<br> 2:信号丢失<br> 3:铜片接触<br> 4:对接成功<br> 5:对接错误（碰撞或充电过程中脱落）<br> 7:关闭回充底盘退出<br> 8:回充流程任务结束/红外回充任务为关闭状态 |

## dt_current.msg

回充状态

| 类型    | 名称  | 单位 | 含义       | 说明                 |
|---------|-------|------|------------|----------------------|
| float32 | left  | A    | 左电机电流 | 前进:正数  后退:负数 |
| float32 | right | A    | 右电机电流 | 前进:正数  后退:负数 |


## dt_date.msg

出货日期

| 类型  | 名称  | 单位   | 含义 | 说明       |
|-------|-------|--------|------|------------|
| uint8 | year  | number | 年   | 省略20开头 |
| uint8 | month | number | 月   | 1 \-> 12   |
| uint8 | day   | number | 日   | 1 \-> 31   |

## dt_drive_error.msg

驱动器错误

| 类型   | 名称            | 单位   | 含义     | 说明               |
|--------|-----------------|--------|----------|--------------------|
| struct | left\_hollysys  | struct | 左路错误 | 驱动器Hollysys错误 |
| struct | right\_hollysys | struct | 右路错误 | 驱动器Hollysys错误 |
| struct | left\_sdfz      | struct | 左路错误 | 驱动器SDFZ错误     |
| struct | right\_sdfz     | struct | 右路错误 | 驱动器SDFZ错误     |

## dt_drive_hollysys_error.msg

驱动器错误信息

| 类型   | 名称                                                     | 单位    | 含义                       | 说明                      |
|------|------------------------------------------------------------|---------|----------------------------|---------------------------|
| bool | encoder\_abz\_fault\_alarm                                 | boolean | 编码器故障ABZ报警          | false:无错误  true:有错误 |
| bool | encoder\_uvw\_fault\_alarm                                 | boolean | 编码器故障UVW报警          | false:无错误  true:有错误 |
| bool | position\_error                                            | boolean | 位置超差                   | false:无错误  true:有错误 |
| bool | stall                                                      | boolean | 失速                       | false:无错误  true:有错误 |
| bool | current\_sampling\_midpoint\_fault                         | boolean | 电流采样（中点）故障       | false:无错误  true:有错误 |
| bool | overload                                                   | boolean | 过载                       | false:无错误  true:有错误 |
| bool | undervoltage                                               | boolean | 欠压                       | false:无错误  true:有错误 |
| bool | overvoltage                                                | boolean | 过压                       | false:无错误  true:有错误 |
| bool | overcurrent                                                | boolean | 过流                       | false:无错误  true:有错误 |
| bool | discharge\_alarm\_instant\_power\_high                     | boolean | 放电报警瞬时功率大         | false:无错误  true:有错误 |
| bool | discharge\_circuit\_frequent\_action\_average\_power\_high | boolean | 放电回路频繁动作平均功率大 | false:无错误  true:有错误 |
| bool | parameter\_read\_write\_error                              | boolean | 参数读写异常               | false:无错误  true:有错误 |
| bool | input\_function\_duplicate\_definition                     | boolean | 输入口功能定义重复         | false:无错误  true:有错误 |
| bool | communication\_watchdog\_triggered                         | boolean | 通讯看门狗触发             | false:无错误  true:有错误 |
| bool | motor\_overtemperature\_alarm                              | boolean | 电机过温报警               | false:无错误  true:有错误 |

## dt_drive_sdfz_error.msg

驱动器错误信息

| 类型   | 名称                   | 单位    | 含义                          | 说明                      |
|------|--------------------------|---------|-------------------------------|---------------------------|
| bool | internal                 | boolean | 内部错误                      | false:无错误  true:有错误 |
| bool | encoder\_abz             | boolean | 编码器ABZ信号错误             | false:无错误  true:有错误 |
| bool | encoder\_uvw             | boolean | 编码器UVW信号错误             | false:无错误  true:有错误 |
| bool | encoder\_count           | boolean | 编码器计数错误                | false:无错误  true:有错误 |
| bool | drive\_overtemp          | boolean | 驱动器温度过高                | false:无错误  true:有错误 |
| bool | drive\_bus\_overvoltage  | boolean | 驱动器母线电压过高            | false:无错误  true:有错误 |
| bool | drive\_bus\_undervoltage | boolean | 驱动器母线电压过低            | false:无错误  true:有错误 |
| bool | drive\_short\_circuit    | boolean | 驱动器输出短路                | false:无错误  true:有错误 |
| bool | brake\_overtemp          | boolean | 驱动器制动电阻过温报警        | false:无错误  true:有错误 |
| bool | actual\_following        | boolean | 实际跟随误差超过允许值        | false:无错误  true:有错误 |
| bool | reserved                 | boolean | 保留备用                      | false:无错误  true:有错误 |
| bool | i2t                      | boolean | I2\*T故障（驱动器或电机过载） | false:无错误  true:有错误 |
| bool | speed\_following         | boolean | 速度跟随误差超过允许值        | false:无错误  true:有错误 |
| bool | motor\_overtemp          | boolean | 电机过温报警                  | false:无错误  true:有错误 |
| bool | encoder\_comm            | boolean | 寻找电机错误（通讯式编码器）  | false:无错误  true:有错误 |
| bool | comm\_loss               | boolean | 通信掉线报警                  | false:无错误  true:有错误 |

## dt_hardware_version.msg

硬件版本

| 类型       | 名称    | 单位  | 含义     | 说明 |
|------------|---------|-------|----------|------|
| uint8\[8\] | version | array | 硬件版本 | 保留 |

## dt_led_strip.msg

灯条数据

| 类型    | 名称       | 单位   | 含义     | 说明                   |
|---------|------------|--------|----------|------------------------|
| uint8   | id         | number | 灯条编号 | 不存在编号会设置失败   |
| uint8   | mode       | number | 灯光模式 | 0:常亮  1:闪烁  2:呼吸 |
| uint8   | brightness | %      | 亮度     | 0 - 100                |
| float32 | interval   | s      | 时间间隔 | 0.0 - 25.5<br> 常亮:无作用<br> 闪烁:闪烁间隔<br> 呼吸:呼吸间隔 |
| uint8   | r          | number | 红       | 0 - 255                |
| uint8   | g          | number | 绿       | 0 - 255                |
| uint8   | b          | number | 蓝       | 0 - 255                |

## dt_led_strips.msg

多个灯条

| 类型       | 名称  | 单位   | 含义         | 说明 |
|------------|-------|--------|--------------|------|
| struct\[\] | leds  | struct | 多个灯条数据 |      |

## dt_parameter.msg

底盘参数

| 类型   | 名称            | 单位   | 含义   | 说明 |
|--------|-----------------|--------|--------|------|
| uint16 | track\_width    | mm     | 轮距   |      |
| uint16 | wheel\_base     | mm     | 轴距   |      |
| uint16 | wheel\_diameter | mm     | 直径   |      |
| uint16 | gear\_ratio     | number | 减速比 |      |
| uint16 | encoder\_line   | number | 线数   |      |

## dt_remote_ctrl.msg

遥控数据

| 类型  | 名称              | 单位    | 含义         | 说明                     |
|-------|-------------------|---------|--------------|--------------------------|
| int16 | right\_rocker\_x  | number  | 右摇杆左右   | 左:\-584  中:0  右:583   |
| int16 | right\_rocker\_y  | number  | 右摇杆上下   | 下:\-584  中:0  上:583   |
| int16 | left\_rocker\_y   | number  | 左摇杆上下   | 下:\-584  中:0  上:583   |
| int16 | left\_rocker\_x   | number  | 左摇杆左右   | 左:\-584  中:0  右:583   |
| int16 | left\_round\_vra  | number  | 左拨轮前后   | 后:\-584  中:0  前:583   |
| int16 | right\_round\_vrb | number  | 右拨轮前后   | 后:\-584  中:0  前:583   |
| uint8 | key\_swa          | number  | 拨杆swa      | 0:下  1:中  2:上  3:保留 |
| uint8 | key\_swb          | number  | 拨杆swb      | 0:下  1:中  2:上  4:保留 |
| uint8 | key\_swc          | number  | 拨杆swc      | 0:下  1:中  2:上  5:保留 |
| uint8 | key\_swd          | number  | 拨杆swd      | 0:下  1:中  2:上  6:保留 |
| bool  | is\_offline       | boolean | 遥控在线状态 | false:在线  true:离线    |

## dt_software_version.msg

软件版本

| 类型       | 名称              | 单位   | 含义         | 说明                 |
|------------|-------------------|--------|--------------|----------------------|
| uint8      | major\_version    | number | 主版本号     |                      |
| uint8      | minor\_version    | number | 次版本号     |                      |
| uint8      | revision\_version | number | 修订版本号   |                      |
| uint8      | other\_version    | number | 其他版本号   |                      |
| uint8      | year\_version     | number | 年           |                      |
| uint8      | month\_version    | number | 月           |                      |
| uint8      | day\_version      | number | 日           |                      |
| uint8      | seq\_version      | number | 序列号       |                      |
| uint8\[8\] | version           | array  | 软件版本信息 | 软件版本原始数据数组 |

## dt_state.msg

底盘状态

| 类型    | 名称                  | 单位    | 含义         | 说明                                       |
|---------|-----------------------|---------|--------------|--------------------------------------------|
| uint8   | ctrl\_mode            | number  | 控制模式     | 0:空闲  1:遥控控制  2:通讯控制  3:外部控制 |
| uint8   | battery\_percent      | %       | 电量百分比   | 使用电池电压计算得到                       |
| float32 | battery\_voltage      | V       | 电池电压     | 控制板电压采集                             |
| bool    | stop\_button          | boolean | 急停按钮     | false:弹起  true:按下                      |
| bool    | remote\_ctrl\_stop    | boolean | 遥控急停     | false:解除  true:生效                      |
| bool    | software\_stop        | boolean | 软件急停     | false:解除  true:生效                      |
| bool    | remote\_ctrl\_offline | boolean | 遥控掉线     | false:未掉线  true:掉线                    |
| bool    | front\_collision      | boolean | 前防撞杆触发 | false:未触发  true:触发                    |
| bool    | back\_collision       | boolean | 后防撞杆触发 | false:未触发  true:触发                    |
| bool    | charge\_enable        | boolean | 回充开启     | false:关闭  true:开启                      |
| bool    | drive\_offline        | boolean | 驱动器掉线   | false:未触发  true:触发                    |
| bool    | drive\_error          | boolean | 驱动器报警   | false:未触发  true:触发                    |
| float64 | linear\_velocity      | m/s     | 线速度       |                                            |
| float64 | angular\_velocity     | rad/s   | 角速度       |                                            |
| int16   | left\_speed           | mm/s    | 左轮速       |                                            |
| int16   | right\_speed          | mm/s    | 右轮速       |                                            |



## 版本信息

当前: V 1.1.1 <br>

V 1.1.1 <br>
++新增电池bms的msg文件

V 1.1.0 <br>
++底盘驱动器更新为SDFZ，新增SDFZ驱动器错误消息 <bt>
++新增灯条的msg文件

V 1.0.0 <br>
++首次创建