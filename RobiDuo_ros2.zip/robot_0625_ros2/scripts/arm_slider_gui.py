#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray

try:
    import tkinter as tk
except ImportError:
    import Tkinter as tk


COMMAND_JOINTS = [
    "L_shoulder",
    "L_arm1",
    "L_arm2",
    "L_wrist1",
    "L_wrist2",
    "L_claw",
    "L_finger_l",
    "R_shoulder",
    "R_arm1",
    "R_arm2",
    "R_wrist1",
    "R_wrist2",
    "R_claw",
    "R_finger_r",
]

SLIDERS = [
    ("L_shoulder", -1.57, 1.57, 0.01),
    ("L_arm1", -0.52, 1.75, 0.01),
    ("L_arm2", -0.79, 2.36, 0.01),
    ("L_wrist1", -1.57, 1.57, 0.01),
    ("L_wrist2", -1.57, 1.57, 0.01),
    ("L_claw", -1.57, 1.57, 0.01),
    ("L_finger_l", 0.0, 0.03, 0.001),
    ("R_shoulder", -1.57, 1.57, 0.01),
    ("R_arm1", -0.52, 1.75, 0.01),
    ("R_arm2", -0.79, 2.36, 0.01),
    ("R_wrist1", -1.57, 1.57, 0.01),
    ("R_wrist2", -1.57, 1.57, 0.01),
    ("R_claw", -1.57, 1.57, 0.01),
    ("R_finger_r", 0.0, 0.03, 0.001),
]
SLIDER_JOINTS = {}


class ArmSliderGui(Node):
    def __init__(self):
        super().__init__("arm_slider_gui")
        self.declare_parameter("command_topic", "/arm_position_controller/commands")
        topic = self.get_parameter("command_topic").value
        self.publisher = self.create_publisher(Float64MultiArray, topic, 10)

        self.root = tk.Tk()
        self.root.title("robot_0625_ros2 arm control")
        self.root.protocol("WM_DELETE_WINDOW", self.close)

        self.values = {}
        for row, (name, lower, upper, resolution) in enumerate(SLIDERS):
            tk.Label(self.root, text=name, width=12, anchor="w").grid(
                row=row, column=0, padx=6, pady=3
            )
            value = tk.DoubleVar(value=0.0)
            self.values[name] = value
            scale = tk.Scale(
                self.root,
                from_=lower,
                to=upper,
                resolution=resolution,
                orient=tk.HORIZONTAL,
                length=420,
                variable=value,
                command=lambda _raw: self.publish(),
            )
            scale.grid(row=row, column=1, padx=6, pady=3)

        tk.Button(self.root, text="Reset", command=self.reset).grid(
            row=len(SLIDERS), column=0, columnspan=2, sticky="ew", padx=6, pady=8
        )

    def publish(self):
        command_values = {name: self.values[name].get() for name, *_ in SLIDERS}

        msg = Float64MultiArray()
        msg.data = [command_values[name] for name in COMMAND_JOINTS]
        self.publisher.publish(msg)

    def reset(self):
        for value in self.values.values():
            value.set(0.0)
        self.publish()

    def close(self):
        self.root.destroy()
        rclpy.shutdown()

    def spin_gui(self):
        while rclpy.ok():
            rclpy.spin_once(self, timeout_sec=0.0)
            self.root.update_idletasks()
            self.root.update()


def main():
    rclpy.init()
    node = ArmSliderGui()
    try:
        node.spin_gui()
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
