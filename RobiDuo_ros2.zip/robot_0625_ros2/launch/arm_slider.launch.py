from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([
        Node(
            package="robot_0625_ros2",
            executable="arm_slider_gui.py",
            parameters=[{"command_topic": "/arm_position_controller/commands"}],
            output="screen",
        )
    ])
