import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    pkg_share = get_package_share_directory("robot_0625_ros2")
    urdf_file = os.path.join(pkg_share, "urdf", "robot_0625_ros2.urdf")

    with open(urdf_file, "r", encoding="utf-8") as f:
        robot_description = f.read()
    robot_description = robot_description.replace(
        "$(find robot_0625_ros2)",
        pkg_share,
    )

    return LaunchDescription([
        Node(
            package="robot_state_publisher",
            executable="robot_state_publisher",
            parameters=[{"robot_description": robot_description}],
            output="screen",
        ),
        Node(
            package="joint_state_publisher_gui",
            executable="joint_state_publisher_gui",
            output="screen",
        ),
        Node(
            package="rviz2",
            executable="rviz2",
            output="screen",
        ),
    ])
