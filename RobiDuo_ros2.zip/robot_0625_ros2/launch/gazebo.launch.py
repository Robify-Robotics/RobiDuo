import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, SetEnvironmentVariable, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node


def generate_launch_description():
    pkg_share = get_package_share_directory("robot_0625_ros2")
    gz_resource_path = os.pathsep.join(
        path
        for path in [
            os.path.dirname(pkg_share),
            os.environ.get("GZ_SIM_RESOURCE_PATH", ""),
        ]
        if path
    )
    urdf_path = os.path.join(pkg_share, "urdf", "robot_0625_ros2.urdf")

    with open(urdf_path, "r", encoding="utf-8") as f:
        robot_description = f.read()
    robot_description = robot_description.replace(
        "$(find robot_0625_ros2)",
        pkg_share,
    )

    gz_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                get_package_share_directory("ros_gz_sim"),
                "launch",
                "gz_sim.launch.py",
            )
        ),
        launch_arguments={"gz_args": "-r --physics-engine gz-physics-bullet-featherstone-plugin empty.sdf"}.items(),
    )

    robot_state_publisher = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        parameters=[{"robot_description": robot_description}],
        output="screen",
    )

    spawn_robot = Node(
        package="ros_gz_sim",
        executable="create",
        arguments=[
            "-name",
            "robot_0625_ros2",
            "-topic",
            "robot_description",
            "-z",
            "0.0",
        ],
        output="screen",
    )

    joint_state_broadcaster = Node(
        package="controller_manager",
        executable="spawner",
        arguments=["joint_state_broadcaster"],
        output="screen",
    )

    arm_position_controller = Node(
        package="controller_manager",
        executable="spawner",
        arguments=["arm_position_controller"],
        output="screen",
    )

    arm_slider = Node(
        package="robot_0625_ros2",
        executable="arm_slider_gui.py",
        parameters=[{"command_topic": "/arm_position_controller/commands"}],
        output="screen",
    )

    return LaunchDescription([
        SetEnvironmentVariable("GZ_SIM_RESOURCE_PATH", gz_resource_path),
        gz_launch,
        robot_state_publisher,
        spawn_robot,
        TimerAction(period=3.0, actions=[joint_state_broadcaster]),
        TimerAction(period=4.0, actions=[arm_position_controller]),
        TimerAction(period=5.0, actions=[arm_slider]),
    ])
